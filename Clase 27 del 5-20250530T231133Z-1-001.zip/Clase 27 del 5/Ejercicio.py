def replace():
    s=input("Ingrese cadena: ")
    print(s.replace(input("Ingrese el valor a reemplaza: "), input("Ingrese el valor reemplazante: ")))

def upper():
    e= input("Poner texto a pasar a mayuscula:")
    print(e.upper())

def dividir_cadena():
    b= input("Ingresar cadena a dividir con ,: ")
    print(b.split(","))

def longitud_de_cadena():
    a= len(input("Ingresar cadena a medir: "))
    print(a)

def preguntar_edad():
    f= "Yo tengo {variable} años".format(variable=int(input("Ingrese edad: ")))
    print(f)


def borrar_espacios():
    texto= str(input("Ingrese una cadena de texto con espacio al empezar y al terminar: "))
    return texto.strip()






def pasar_a_minisculas():
    z= input("Poner texto en mayuscula: ").lower()
    print(z)

#preguntar_edad()
#pasar_a_minisculas()
#longitud_de_cadena()
#upper()
#dividir_cadena()
#print(borrar_espacios())
replace()