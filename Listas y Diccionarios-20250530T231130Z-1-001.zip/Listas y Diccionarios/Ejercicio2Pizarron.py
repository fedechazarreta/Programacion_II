entrada = input("Ingresa una lista de palabras separadas por espacios: ")

palabras = entrada.split() 

contador = {}

for palabra in palabras:
    if palabra in contador: 
        contador[palabra] += 1 
    else: 
        contador[palabra] = 1 
        
print("\nCantidad de apariciones de cada palabra:") 
for palabra, cantidad in contador.items(): 
    print(f"{palabra}: {cantidad}") 