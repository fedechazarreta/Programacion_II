tupla= ("river", "independiente", "racing", "huracan", "san lorenzo", "boca juniors", "estudiantes")
print(tupla[2:5])