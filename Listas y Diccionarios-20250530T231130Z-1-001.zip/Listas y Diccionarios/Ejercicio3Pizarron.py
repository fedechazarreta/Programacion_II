lista_Ceros= [10, 20, 30, 40, 50, 0, 0, 0, 0, 505, 0]
lista_Sin_Ceros= [num for num in lista_Ceros if num !=0 ]

print(lista_Ceros)
print(lista_Sin_Ceros)

