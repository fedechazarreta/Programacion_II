diccionario = {"seba": 1, "hoy": 2, "falto :c": 3}
invertido = {v: k for k, v in diccionario.items()}
print("Invertido:", invertido)