agenda = {}
for _ in range(3):
    nombre = input("Nombre: ")
    telefono = input("Teléfono: ")
    agenda[nombre] = telefono

busqueda = input("Buscar teléfono de: ")
print("Teléfono:", agenda.get(busqueda, "No encontrado"))