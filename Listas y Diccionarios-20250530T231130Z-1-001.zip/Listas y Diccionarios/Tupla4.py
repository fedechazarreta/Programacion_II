lista= tuple([input("Ingrese elementos, luego de cada elemento añadir coma")])
print(lista)