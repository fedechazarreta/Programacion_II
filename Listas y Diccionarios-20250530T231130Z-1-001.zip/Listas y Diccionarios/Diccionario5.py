dic1 = {"morenita": 1, "morena": 2}
dic2 = {"aguirre": 3, "mor": 4}
unido = {**dic1, **dic2}
print("Diccionario unido:", unido)