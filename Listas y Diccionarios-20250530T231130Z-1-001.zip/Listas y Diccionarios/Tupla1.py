dias = ("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")

numero = int(input("Ingrese numero del 0 al 6 segun el dia: "))
if 0 <= numero <= 6:
    print("dia", dias[numero])
else:
    print("error numero")