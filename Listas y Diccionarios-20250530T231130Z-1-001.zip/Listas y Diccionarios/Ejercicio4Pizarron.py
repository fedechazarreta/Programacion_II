notas=[]
while True:
    nota= int(input("Ingrese una nota: "))
    if nota == -1:
        break
    notas.append(nota)
print("Notas: ", notas)
if notas:
    promedio= sum(notas) / len(notas)
    print("Promedio: ", promedio)
else:
    print("No se ingresaron notas")