elementos= input("Ingrese elementos separados por coma:"). split(" , ")
print("Lista original: ", elementos)

sin_repetir=[]
for i in elementos:
    if i not in elementos:
        sin_repetir.append(i)
print(sin_repetir)