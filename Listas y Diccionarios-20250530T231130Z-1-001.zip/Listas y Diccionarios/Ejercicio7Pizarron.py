lista = []

while True:
    numero= input("Ingrese un numero: ")
    if numero == 4:
        break                     #corta el bucle (while) cuando el usuario ingrese "fin"
    lista.append(numero)
    
print(lista.reverse())
    
