lista_hoy = ("Hola", "Chau", "Buenas")
lista_pacho = ("Buzo", "Campera", "Termica")
lista = lista_hoy+lista_pacho

print(lista)