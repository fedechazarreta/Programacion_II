lista_numeros = [-2, 2, 5, 6,45,3,2,2,-200,-3,-3,-3]
lista_sin_negativos = [abs(num) for num in lista_numeros]
 
print(lista_sin_negativos)
print(lista_numeros)