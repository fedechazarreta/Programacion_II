alumnos = {}
for _ in range(2):
    nombre = input("Nombre del alumno: ")
    notas = list(map(float, input("Notas separadas por espacio: ").split()))
    alumnos[nombre] = notas

for alumno, notas in alumnos.items():
    promedio = sum(notas) / len(notas)
    print(f"{alumno}: promedio = {promedio}")