nombres =[]

cantidad= int(input("Ingrese la cantidad de nombres: "))

for i in range (cantidad):
    nombres.append(input("Ingrese el nombre: "))
print("Lista original: ", nombres)
nombres.sort() 
print("Lista ordenada alfabeticamente: ", nombres)