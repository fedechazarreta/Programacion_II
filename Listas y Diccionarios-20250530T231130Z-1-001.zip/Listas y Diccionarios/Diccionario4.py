inventario = {"verdura": 10, "fruta": 5}
producto = input("Producto: ")
cantidad = int(input("Cantidad (+ para sumar, - para restar): "))
inventario[producto] = inventario.get(producto, 0) + cantidad
print("Inventario actualizado:", inventario)