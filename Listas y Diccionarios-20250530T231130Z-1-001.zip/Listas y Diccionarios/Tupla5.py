numeros = (12, 13,14,15,16,17)

numero_usario = int(input("Ingrese numero: "))
if numero_usario in numeros:
    print("numero en tupla")
else:
    print("NO esta en la tupla")