palabra= input("ingrese una palabra")

conteo_letra= {}

for letra in palabra:
    if letra.isalpha():
        if letra in conteo_letra:
            conteo_letra[letra] +=1
        else:
            conteo_letra[letra] =1

print (conteo_letra)