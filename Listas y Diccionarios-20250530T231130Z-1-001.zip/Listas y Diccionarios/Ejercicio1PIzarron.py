numeros = []
numeros_no_negativos = []

for i in range (10):
    num=int(input("Ingrese un numero: "))
    numeros.append(num)
    if num >= 0:
        numeros_no_negativos.append(num)

print("lista original: ", numeros)
print("lista de numeros no negativos: ", numeros_no_negativos)