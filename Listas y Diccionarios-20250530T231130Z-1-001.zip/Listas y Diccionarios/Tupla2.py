numeros= (2,3,4,5,2,6,7,3,2)
print (numeros.count(2))